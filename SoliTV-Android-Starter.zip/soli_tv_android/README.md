# Soli TV Android App – Starter Project

This is the first native Android starter version for Soli TV. It uses the supplied Soli TV logo and includes navigable starter screens for News, Videos, Facebook Live, Soli Language & Culture, Advertising & Sponsorship, and Breaking News Notifications.

## Open the project
1. Download and extract `SoliTV-Android-Starter.zip`.
2. Install Android Studio on a computer.
3. In Android Studio, choose **Open** and select the extracted `soli_tv_android` folder.
4. Allow Android Studio to download the Gradle and Android dependencies.
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Press **Run** to install the starter app.

## Important setup before testing Live TV
Open `app/src/main/res/values/strings.xml` and replace the placeholder `facebook_page_url` with the exact public Soli TV Facebook Page URL.

## Current prototype limitations
- News and video pages are starter screens; no publishing backend is connected yet.
- Facebook Live opens the configured Facebook Page. Facebook may require users to sign in or may open the Facebook app/browser; embedded playback is not guaranteed.
- Breaking-news push notifications are not connected yet. A Firebase project and notification setup are required.
- The app has not been built, signed, or tested on a device in this environment. This source project is not an APK yet.

## Planned next development stages
1. Add an admin publishing system for news, photos and video links.
2. Connect Firebase Cloud Messaging for breaking-news notifications.
3. Confirm the Facebook Page URL and test the Live entry point.
4. Test on Android devices, then create a signed release APK/AAB.
5. Prepare Google Play Store listing and privacy policy.
