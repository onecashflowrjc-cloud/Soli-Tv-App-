package com.solitv.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val orange = Color.rgb(245, 160, 0)
    private val dark = Color.rgb(28, 28, 28)
    private val red = Color.rgb(205, 45, 62)
    private val green = Color.rgb(30, 100, 65)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = dark, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
    }

    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }
    }

    private fun startPage(title: String, subtitle: String) {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(255, 250, 239))
            setPadding(dp(18), dp(12), dp(18), dp(24))
        }
        scroll.addView(root)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(orange)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.soli_tv_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Soli TV official logo"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(66), dp(66)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("SOLI TV", 22f, Color.BLACK, true))
        brand.addView(text("Preserving our culture, telling our story", 11f, Color.BLACK))
        header.addView(brand)
        root.addView(header)
        root.addView(text(title, 25f, dark, true))
        root.addView(text(subtitle, 14f, Color.DKGRAY))
        root.addView(button("Home", { showHome() }))
        content = root
        setContentView(scroll)
    }

    private fun showHome() {
        startPage("Welcome to Soli TV", "Your voice. Your culture. Your news.")
        content.addView(text("Stay connected with news, videos, live broadcasts and the Soli heritage.", 16f))
        content.addView(text("EXPLORE SOLI TV", 16f, red, true))
        content.addView(button("Latest News", { showSection("News", "Community, Chongwe, Soli land and national updates.") }))
        content.addView(button("Videos", { showSection("Videos", "Watch Soli TV reports, interviews and programmes.") }))
        content.addView(button("LIVE TV – Facebook Live", { openFacebook() }))
        content.addView(button("Soli Language & Culture", { showCulture() }))
        content.addView(button("Advertising & Sponsorship", { showAdvertising() }))
        content.addView(button("Breaking News Notifications", { showNotifications() }))
        content.addView(text("Follow Soli TV on Facebook for the latest updates.", 13f, Color.DKGRAY))
    }

    private fun showSection(title: String, description: String) {
        startPage(title, description)
        content.addView(text("This section is ready for Soli TV content. Articles and videos will appear here after the app is connected to a publishing service.", 15f))
        content.addView(button("Visit Soli TV on Facebook", { openFacebook() }))
    }

    private fun showCulture() {
        startPage("Soli Language & Culture", "Preserving our language, history and traditions.")
        content.addView(text("This section will feature Soli words and meanings, pronunciation lessons, stories, ceremonies, history and cultural programmes.", 15f))
        content.addView(text("Content coming as Soli TV prepares its first language and culture lessons.", 13f, Color.DKGRAY))
    }

    private fun showAdvertising() {
        startPage("Advertising & Sponsorship", "Partner with Soli TV and reach our community.")
        content.addView(text("For advertising, programme partnerships and sponsorship enquiries:", 15f))
        content.addView(text("WhatsApp: +260 979 975 903", 18f, green, true))
        content.addView(button("Contact Soli TV on WhatsApp", {
            val number = getString(R.string.whatsapp_number)
            val uri = Uri.parse("https://wa.me/$number")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }))
    }

    private fun showNotifications() {
        startPage("Breaking News Notifications", "Important updates from Soli TV.")
        content.addView(text("Breaking-news push alerts will be enabled after the app is connected to its notification service. For now, follow Soli TV on Facebook and enable Page notifications there.", 15f))
        content.addView(button("Open Soli TV Facebook Page", { openFacebook() }))
    }

    private fun openFacebook() {
        val url = getString(R.string.facebook_page_url)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Facebook link is not available yet.", Toast.LENGTH_LONG).show()
        }
    }
}
